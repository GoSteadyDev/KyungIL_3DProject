using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

public class CannonTower : BaseTower
{
    [Header("Fire Points")]
    [SerializeField] private Transform[] firePoints;  // 발사구 위치 배열
    [Header("Enemy Mask")]
    [SerializeField] private LayerMask enemyLayerMask;

    private Animator animator;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    protected override void RefreshStats() { /* 캐논은 아처타워와 달리, 내부 유닛이 아닌 발사체 생성 방식이므로 빈 구현 */ }

    public override string GetDescription()
    {
        bool isMultiBurst = data.attackData.burstCount > 1;

        if (isMultiBurst)
        {
            float totalDPS = data.damage;
            return $"\n- Total DPS: {totalDPS:F1}" +
                   $"\n- Explosion Radius: {data.attackData.areaRadius}" +
                   $"\n- Attack Speed: {data.attackSpeed:F2}" +
                   $"\n- Burst Count: {data.attackData.burstCount}";
        }

        // 기본 설명 + 폭발 반경
        string desc = base.GetDescription();
        desc += $"\n- Explosion Radius: {data.attackData.areaRadius}";
        return desc;
    }
    
    protected override Transform FindTarget()
    {
        // 최소 사거리 내 가장 가까운 적 반환
        Collider[] hits = Physics.OverlapSphere(transform.position, data.attackRange, enemyLayerMask);
        if (hits.Length == 0) return null;

        Transform nearest = hits[0].transform;
        float minDist = (nearest.position - transform.position).sqrMagnitude;
        foreach (var c in hits)
        {
            float d = (c.transform.position - transform.position).sqrMagnitude;
            if (d < minDist)
            {
                minDist = d;
                nearest = c.transform;
            }
        }
        return nearest;
    }

    protected override void Attack(Transform target)
    {
        if (data.attackData.burstCount > 1)
            StartCoroutine(FireSequentialBurst(target));
        else
            FireFromPoint(firePoints[0], target);
    }

    private IEnumerator FireSequentialBurst(Transform target)
    {
        animator.SetTrigger("IsAttack");
        
        if (target == null) yield break;
    
        // burstCount 만큼 순차 발사
        for (int i = 0; i < data.attackData.burstCount; i++)
        {
            // 포구 인덱스 순환 (포구 3개면 0→1→2→0→…)
            Transform fp = firePoints[i % firePoints.Length];
            FireFromPoint(fp, target);
            yield return new WaitForSeconds(data.attackData.burstInterval);
        }
    }

    private void FireFromPoint(Transform fp, Transform target)
    {
        if (target == null) return;

        // 예측 위치 계산 (이전 로직 그대로)
        Vector3 enemyPos   = target.position;
        var controller     = target.GetComponent<EnemyController>();
        Vector3 enemyVel   = controller != null ? controller.GetVelocity() : Vector3.zero;
        
        Vector3 shooterPos = fp.position;
        float speed        = data.attackData.projectileSpeed;
        float flightTime   = Vector3.Distance(enemyPos, shooterPos) / speed;
        float factor       = data.attackData.overshootFactor;
        
        Vector3 aimPoint   = enemyPos + enemyVel * (flightTime * factor);

        // Instantiate 후 Initialize
        var go = Instantiate(data.attackData.projectilePrefab, shooterPos, Quaternion.identity);
        var cannon = go.GetComponent<Cannon>();
        cannon.Initialize(shooterPos, aimPoint, flightTime, data.damage, data.attackData, enemyLayerMask);
    }
}
