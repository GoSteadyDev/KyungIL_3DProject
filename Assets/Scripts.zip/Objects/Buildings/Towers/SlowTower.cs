using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowTower : MonoBehaviour, IHasRangeUI, IHasInfoPanel, ITower
{
    [Header("Tower Settings")]
    [SerializeField] private TowerType TowerType;
    [SerializeField] private int currentLevel = 0;
    [SerializeField] private float damage = 5f;
    [SerializeField] private float slowRate = 0.25f;
    [SerializeField] private float slowDuration = 3f;
    [SerializeField] private float attackRange = 7.5f;
    
    [Header("Projectile Settings")]
    [SerializeField] private GameObject slowEffectPrefab;   // 얘도 LazerTower처럼 이펙트 오브젝트를 쓴다
    
    [Header("Visual Settings")]
    [SerializeField] private Sprite icon;
    
    [Header("InfoPanel")]
    [SerializeField] private string displayName;
    [SerializeField] private string displayLevel;
    [SerializeField] private float displayDamage;
    [SerializeField] private float displayRange;
    
    private Transform targetTransform;
    private Animator animator;
    
    private bool isFiring = false;
    private float currentCooldown;

    private int damagePerSec => Mathf.CeilToInt(damage / slowDuration);
    public Sprite GetIcon() => icon;
    public string GetDisplayName() => displayName;
    public string GetDescription() 
        => $"Tower Level : {displayLevel} \nDamage: {displayDamage} \nSlow: {slowRate * 100}% / {slowDuration} \nAttackRange : {displayRange}";
    public float GetAttackRange() => attackRange;
    public Transform GetTransform() => transform;
    public TowerType GetTowerType() => TowerType;
    public int GetCurrentLevel() => currentLevel;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        FindTarget();

        if (targetTransform != null)
        {
           animator.SetTrigger("IsAttack");
           if (!isFiring) Fire();
        }
    }

    private void FindTarget()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, attackRange, LayerMask.GetMask("Enemy"));
        targetTransform = hits.Length > 0 ? hits[0].transform : null;
    }

    private void Fire()
    {
        if (targetTransform == null || isFiring) return;

        isFiring = true;

        EnemyController enemy = targetTransform.GetComponent<EnemyController>();
        if (enemy == null) return;

        enemy.ApplySlow(slowRate, slowDuration, slowEffectPrefab);

        StartCoroutine(ApplySlowDamageAndReset(enemy.gameObject, damagePerSec, slowDuration));
    }

    // 여기서 적 데미지 한번에 들어가서 애먹었던 기억이 있네. 디버그에 2중 코루틴 준거 추가할만할까?
    private IEnumerator ApplySlowDamageAndReset(GameObject target, float damagePerSecond, float duration)
    {
        yield return StartCoroutine(SlowDamageCoroutine(target, damagePerSecond, duration));
        isFiring = false;
    }
    
    private IEnumerator SlowDamageCoroutine(GameObject target, float damagePerSecond, float duration)
    {
        int tickCount = Mathf.FloorToInt(duration); // 1초 단위로 나누기

        for (int i = 0; i < tickCount; i++)
        {
            yield return new WaitForSeconds(1f); // ✅ 1초마다 데미지 전달

            if (target == null) yield break;

            CombatEvent combatEvent = new CombatEvent
            {
                Sender = this.gameObject,
                Receiver = target,
                Damage = damagePerSecond,
                HitPosition = target.transform.position,
                Collider = target.GetComponent<Collider>()
            };

            CombatSystem.Instance.AddCombatEvent(combatEvent);
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}