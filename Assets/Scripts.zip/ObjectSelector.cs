using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public interface IClickable 
{
    Transform GetTransform();
}

public interface IHasRangeUI : IClickable
{
    float GetAttackRange();
}

public interface IHasInfoPanel
{
    Sprite GetIcon();
    string GetDisplayName();
    string GetDescription(); // 나중에 확장 가능
}

public class ObjectSelector : MonoBehaviour
{
    public static ObjectSelector Instance;
    
    [SerializeField] private Camera mainCamera;
    [SerializeField] private RangeViewerController rangeViewer;

    private ITower currentSelectedTower;
    public ITower CurrentSelectedTower => currentSelectedTower;
    
    private void Awake()
    {
        Instance = this;
        
        if (mainCamera == null)
            mainCamera = Camera.main;
    }

    private void Update()
    {
        if (EventSystem.current.IsPointerOverGameObject()) return;

        if (Input.GetMouseButtonDown(0))
        {
            HandleMouseClick();
        }
    }

    private void HandleMouseClick()
    {
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        if (!Physics.Raycast(ray, out var hit)) return;

        // 0) 이전 모든 UI 닫기
        UIManager.Instance.HideAllTowerPanels();

        // 1) 범위(Range) 표시
        HandleRangeUI(hit);

        // 2) Panel/Info 표시
        HandleInfoPanel(hit);
    }

    private void HandleRangeUI(RaycastHit hit)
    {
        IHasRangeUI hasRangeUI = hit.collider.GetComponent<IHasRangeUI>();

        if (hasRangeUI != null)
        {
            rangeViewer.SetTarget(hasRangeUI.GetTransform(), hasRangeUI.GetAttackRange());
        }
        else
        {
            rangeViewer.Clear();
        }
    }
    
    private void HandleInfoPanel(RaycastHit hit)
    {
        IHasInfoPanel infoTarget = hit.collider.GetComponent<IHasInfoPanel>();

        if (infoTarget != null)
        {
            if (infoTarget is ITower tower)
            {
                HandleTowerPanel(infoTarget);
                UIManager.Instance.ShowTowerInfoPanel(infoTarget, tower.GetTransform());
            }
            else
            {
                UIManager.Instance.ShowUnitInfoPanel(infoTarget);
            }
        }
        else
        {
            UIManager.Instance.HideAllTowerPanels();
            UIManager.Instance.HideTowerGuidePanel();
        }
    }
    
    private void HandleTowerPanel(IHasInfoPanel infoTarget)
    {
        var tower = infoTarget as ITower;
        if (tower != null)
        {
            currentSelectedTower = tower;

            UIManager.Instance.UpdateTowerGuidePanel(tower);
            UIManager.Instance.ShowTowerPanelByLevel(tower.GetCurrentLevel(), tower.GetTransform());
        }
    }
}